import requests
from bs4 import BeautifulSoup

# Fungsi untuk mendapatkan konten halaman web
def get_page_content(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    response = requests.get(url, headers=headers)
    return response.text

# Fungsi untuk mengurai data detail dari halaman produk
def parse_product_detail(content):
    soup = BeautifulSoup(content, 'html.parser')
    details = {}
    
    description_div = soup.find('div', {'data-testid': 'lblPDPDescriptionProduk'})
    details['description'] = description_div.get_text(separator='\n', strip=True) if description_div else 'No Description'

    return details

# URL halaman produk yang ingin di-scrape
product_url = 'https://www.tokopedia.com/zacroofficialshop/zacro-holder-hp-mobil-putar-360-derajat-holder-hp-kaca-spion-tengah?src=topads'

# Mendapatkan konten halaman produk
product_page_content = get_page_content(product_url)

# Mengurai data detail dari halaman produk
product_details = parse_product_detail(product_page_content)

# Menampilkan data produk detail
print("Product Details:")
print(f"Description: {product_details['description']}")

# Simpan data ke file (opsional)
import csv

with open('tokopedia_product_details.csv', mode='w', newline='', encoding='utf-8') as file:
    writer = csv.DictWriter(file, fieldnames=['description'])
    writer.writeheader()
    writer.writerow(product_details)
